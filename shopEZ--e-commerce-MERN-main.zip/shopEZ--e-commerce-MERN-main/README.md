# shopEZ--e-commerce-MERN
Demo - <a href="https://drive.google.com/file/d/12LSyk0rHTb9M3oY0dYaq8x4nDVsBI6j2/view?usp=drive_link">view video</a>
